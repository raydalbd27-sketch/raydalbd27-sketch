import os
import colorsys

print('INSTALL MODULES ')



try: 
    import telebot 
except:
    os.system('python3 -m pip install telebot')
try: 
    import kvsqlite 
except:
    os.system('python3 -m pip install kvsqlite')

try: 
    import schedule 
except:
    os.system('python3 -m pip install schedule')

try: 
    import telebot 
except:
    os.system('python3 -m pip install requests')

try: 
    import user_agent 
except:
    os.system('python3 -m pip install user_agent')

try: 
    import base64 
except:
    os.system('python3 -m pip install base64')

try: 
    import ipaddress 
except:
    os.system('python3 -m pip install ipaddress')

try: 
    import struct 
except:
    os.system('python3 -m pip install struct')

try: 
    import pathlib 
except:
    os.system('python3 -m pip install pathlib')

try: 
    import typing 
except:
    os.system('python3 -m pip install typing')

try: 
    import aiosqlite 
except:
    os.system('python3 -m pip install aiosqlite')

try: 
    import telethon 
except:
    os.system('python3 -m pip install telethon')

try: 
    import pyrogram 
except:
    os.system('python3 -m pip install pyrogram')

try: 
    import opentele
except:
    os.system('python3 -m pip install pyqt5==5.15.4')
    os.system('python3 -m pip install opentele')

try: 
    import secrets 
except:
    os.system('python3 -m pip install secrets')

